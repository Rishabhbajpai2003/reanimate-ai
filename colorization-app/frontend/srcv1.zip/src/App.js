import React, { useState } from "react";
import "./App.css";

function App() {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleUpload = async () => {
    const formData = new FormData();
    formData.append("image", image);

    const res = await fetch("http://127.0.0.1:5000/colorize", {
      method: "POST",
      body: formData,
    });

    const blob = await res.blob();
    setResult(URL.createObjectURL(blob));
  };

  return (
    <div className="container">
      <h1>Image Colorization 🎨</h1>

      <input type="file" onChange={handleChange} />

      {preview && (
        <div>
          <h3>Original</h3>
          <img src={preview} alt="preview" />
        </div>
      )}

      <button onClick={handleUpload}>Colorize</button>

      {result && (
        <div>
          <h3>Colorized</h3>
          <img src={result} alt="result" />
        </div>
      )}
    </div>
  );
}

export default App;
